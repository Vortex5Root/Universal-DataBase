# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['universal_database']

package_data = \
{'': ['*']}

install_requires = \
['python-dotenv>=1.1.1,<2.0.0', 'redis-om>=0.3.5,<0.4.0']

setup_kwargs = {
    'name': 'universal-database',
    'version': '0.1.0',
    'description': '**Universal-DataBase** is a versatile software development kit designed to simplify database operations across SQLite and Redis. It provides a unified interface for CRUD operations, dynamic table creation, and model management, making it ideal for developers working with hybrid database systems.',
    'long_description': '<h1 align="center">Universal-DataBase</h1>\n\n<p align="center">\n    <a href="https://github.com/Vortex5Root/Universal-DataBase/releases"><img alt="Dynamic TOML Badge" src="https://img.shields.io/badge/dynamic-toml?url=https%3A%2F%2Fraw.githubusercontent.com%2FVortex5Root%2FUniversal-DataBase%2Fmain%2Fpyproject.toml&query=%24.tool.poetry.version&logo=data%3Aimage%2Fpng%3Bbase64%2CiVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAMAAAAolt3jAAAAtFBMVEVHcEyWYTihdkuXYzrBjlqhbkHepWuzglG8hFGWYjmzglHepmz3z5iygVCWYjmWYjmxgVDsvorMlmDepmybaD2oe02ufU2leUzdpWqzglGfdUrgqnH616j%2F4LKWYjmvf1C3hVPepmyWYjmWZDuWYjmzglGWYjmwfk7fp22aZjz93a7VoGmpfFKdbEe4hlTFkFzwxZH30aDpuYO%2BnICUbUbGkl3jrnbjr3eSYjuuiWzNq4fjvI5PAatoAAAAJXRSTlMA4v34FBH4Jwwn4l8IXFG6%2FrWcv2PCZqdJxeX291Ci4uVQ5eQoZPLoqAAAAIxJREFUCNdFzscCgjAQBNA1JIAGVMDeW0iEAPb6%2F%2F9lCuqc9s1eBkDHpxTDN8E8mroJ9S1G0Sw7noSbrAMAHLvidshMERPwVlUuxF0Vb7ltgtdi5VUV%2BetcNAwZKyv%2BeP7J%2BD6VRaq5rKmiOUGoW3OzAzxEF2npLIgaGPbN1%2Bm07S4SjvkPOnjQI%2Bb4AGCaEYNClUKKAAAAAElFTkSuQmCC&label=Package%20Version"></a>\n</p>\n\n-------\n\n<p align="center">\n    <a href="https://github.com/Vortex5Root/Universal-DataBase/blob/master/LICENSE"><img src="https://img.shields.io/github/license/Vortex5Root/Universal-DataBase.svg" alt="License"></a>\n    <a href="https://github.com/Vortex5Root/Universal-DataBase/releases"><img src="https://img.shields.io/github/downloads/Vortex5Root/Universal-DataBase/total.svg" alt="GitHub all releases"></a><br>\n    <a href="https://github.com/Vortex5Root/Universal-DataBase/network"><img src="https://img.shields.io/github/forks/Vortex5Root/Universal-DataBase.svg" alt="GitHub forks"></a>\n    <a href="https://github.com/Vortex5Root/Universal-DataBase/stargazers"><img src="https://img.shields.io/github/stars/Vortex5Root/Universal-DataBase.svg" alt="GitHub stars"></a>\n    <a href="https://github.com/Vortex5Root/Universal-DataBase/watchers"><img src="https://img.shields.io/github/watchers/Vortex5Root/Universal-DataBase.svg" alt="GitHub watchers"></a><br>\n    <a href="https://github.com/Vortex5Root/Universal-DataBase/issues"><img src="https://img.shields.io/github/issues/Vortex5Root/Universal-DataBase.svg" alt="GitHub issues"></a>\n    <a href="https://github.com/Vortex5Root/Universal-DataBase/pulls"><img src="https://img.shields.io/github/issues-pr/Vortex5Root/Universal-DataBase.svg" alt="GitHub pull requests"></a>\n    <a href="https://github.com/Vortex5Root/Universal-DataBase/commits/master"><img src="https://img.shields.io/github/last-commit/Vortex5Root/Universal-DataBase.svg" alt="GitHub last commit"></a>\n</p>\n\n<h2 align="center">Introduction</h2>\n\n> **Universal-DataBase** is a versatile software development kit designed to simplify database operations across SQLite and Redis. It provides a unified interface for CRUD operations, dynamic table creation, and model management, making it ideal for developers working with hybrid database systems.\n\n| Problem | Solution |\n| --- | --- |\n| **Managing multiple database types with different APIs is complex.** | **Universal-DataBase provides a unified interface for SQLite and Redis, simplifying database operations.** |\n\n<h2 align="center">Index</h2>\n\n| Topic | Sub Topic | \n| --- | --- |\n| [Requirements](#requirements) | |\n| [Installation](#installation) | |\n| [Usage](#usage) | |\n| [Examples](#examples) | |\n| [Documentation](#documentation) | |\n| [Acknowledgements](#acknowledgements) | |\n\n<h2 align="center">Requirements</h2>\n\n| Name | Version | Description |\n| --- | --- | --- |\n| [![Linux](https://img.shields.io/badge/Linux-A81D33?style=for-the-badge&logo=linux&logoColor=ffffff)](https://www.linux.org/) | 5.14.0 | Linux is a family of open-source Unix-like operating systems based on the Linux kernel. |\n| [![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=ffdd54)](https://www.python.org/) | >=3.11 | Python is an interpreted high-level general-purpose programming language. |\n| [![Poetry](https://img.shields.io/endpoint?url=https://python-poetry.org/badge/v0.json?style=for-the-badge)](https://python-poetry.org/) | 1.1.8 | Poetry is a tool for dependency management and packaging in Python. |\n\n<h2 align="center">Documentation</h2>\n\nClick on the following image to go to the Universal-DataBase Documentation:\n\n<a href=./Documentation.md><img src="./img/wikipedia-svgrepo-com.svg" width=50></a>\n\n<h2 align="center">Acknowledgements</h2>\n\n<p align="center">\n    <br>[Coder]<br>\n    <a href="https://github.com/Vortex5Root"><img src=https://avatars.githubusercontent.com/u/102427260?s=200&v=4 width=50 style="border-radius: 50%;"><br>Vortex5Root <br><b>        {Full-Stack Software Engineer}</b></a><br>\n    <br>[Colaboration With PandemicOfNukes]<br>\n    <a href="https://github.com/PandemicOfNukes"><img src=https://avatars.githubusercontent.com/u/102427260?s=200&v=4 width=50 style="border-radius: 50%;"><br>PandemicOfNukes <br><b>        {Student}</b></a><br><br>\n</p>\n\n',
    'author': 'Vortex5Root',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<3.12',
}


setup(**setup_kwargs)
